/**
 * 
 */
package business.tests;

/**
 * @author Abdi Ahmed, Asha Hassan, Elise Kurtz, Faisal Saeed
 *
 */
public class AutomatedTester {

}
