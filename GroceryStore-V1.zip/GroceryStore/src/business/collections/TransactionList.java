package business.collections;

import java.io.Serializable;
import java.util.Iterator;

import business.entities.Transaction;

public class TransactionList implements Iterable<Transaction>, Serializable{

	
	@Override
	public Iterator<Transaction> iterator() {
		// TODO Auto-generated method stub
		return null;
	}

}
